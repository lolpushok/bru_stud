package com.example.root.bruproject__alpha_10;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.net.Uri;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class BrowserActivity extends AppCompatActivity {
String url;
    WebView wbv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        getSupportActionBar().hide();
        wbv=(WebView)findViewById(R.id.Web);
        wbv.getSettings().setJavaScriptEnabled(true);
        wbv.loadUrl("http://vuz2.bru.by/rate/");
        wbv.setWebViewClient(new WebClicker());



    }
    class MyAppWebViewClient extends WebViewClient  {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            BrowserActivity a=new BrowserActivity();
            a.url=Uri.parse(url).toString();
            return true;
        }


    }
     abstract class MyAppWebViewClient_BrowserActivity extends BrowserActivity
    {

    }
    class WebClicker extends MyAppWebViewClient
    {
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            BrowserActivity a=new BrowserActivity();
            Raiting.url=Uri.parse(url).toString();
            Intent c=new Intent(BrowserActivity.this,Raiting.class);
            startActivity(c);
            return true;
        }
    }


}
